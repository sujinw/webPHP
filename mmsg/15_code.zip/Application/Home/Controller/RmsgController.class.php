<?php
namespace Home\Controller;
use Think\Controller;

class RmsgController extends Controller {
    public function recipemsg() {

    }

    public function editrmsg() {

    }

    public function deletermsg() {
        
    }
}