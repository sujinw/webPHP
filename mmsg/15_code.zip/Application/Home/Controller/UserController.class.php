<?php
namespace Home\Controller;
use Think\Controller;

class UserController extends Controller {
    public function register() {

    }

    public function login() {

    }

    public function logout() {

    }

    public function changepswd() {
        
    }
}