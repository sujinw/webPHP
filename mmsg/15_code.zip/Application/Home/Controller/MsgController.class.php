<?php
namespace Home\Controller;
use Think\Controller;

class MsgController extends Controller {
    public function addmsg() {

    }

    public function editmsg() {

    }

    public function deletemsg() {

    }

    public function index() {
        // 获得数据库操作对象
        // (1) new Model()
        // $db = new \Think\Model();
        // dump($db);
        // (2) M()
        $db = M();

        // 执行SQL原生查询query()
        $results = $db->query("select * from msgs");
        dump($results);

        // 指定视图标题s
        $this->assign('view_title', '首页');
        // 显示视图
        $this->display();
    }

    public function viewmsg() {
        
    }
}