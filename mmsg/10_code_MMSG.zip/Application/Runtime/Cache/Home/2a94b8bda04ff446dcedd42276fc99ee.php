<?php if (!defined('THINK_PATH')) exit();?>    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <div id="header">
        网页页头信息
    </div>    

    <div id="content">
    <p>
        name = <?php echo (substr($name,3,2)); ?>
    </p>
    <p>
        age = <?php echo ($age); ?>
    </p>
    <p>
        version = <?php echo ($arr["version"]); ?>
    </p>
    <p>
        p.person = <?php echo (md5($person->name)); ?>
    </p>
    <p>
        ROOT = /Home/Index
    </p>
    <p>
        student = <?php echo ((isset($student) && ($student !== ""))?($student):"麦子学院"); ?>
    </p>
    <p>
        p = <?php echo ($p?"存在":"不存在"); ?>
    </p>
    <p>
        time = <?php echo (date('y-m-d',$time)); ?>
    </p>
    <p>
        <?php if(($name) == "麦子学院"): ?>name = 麦子学院
        <?php else: ?>
            name = <?php echo ($name); endif; ?>
    </p>
    <p>
        <?php $_RANGE_VAR_=explode(',',"1,5");if($age>= $_RANGE_VAR_[0] && $age<= $_RANGE_VAR_[1]):?>age in {1, 3, 5}
        <?php else: ?>
            age not in {1, 2, 3, 5}<?php endif; ?>
    </p>

    <p>
        <ul>
        <?php if(is_array($persons)): $i = 0; $__LIST__ = array_slice($persons,1,1,true);if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><li><?php echo ($item["name"]); ?> - <?php echo ($item["age"]); ?></li><?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </p>

    <p>
        segment view
    </p>
    </div>
        <div id="footer">
        网页页脚信息
    </div>
</body>
</html>